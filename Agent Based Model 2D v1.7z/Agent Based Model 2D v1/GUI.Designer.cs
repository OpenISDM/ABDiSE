﻿namespace ABDiSE.GUI
{
    partial class MainWindow
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.buttonCreate = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonPause = new System.Windows.Forms.Button();
            this.SimulationTimer = new System.Windows.Forms.Timer(this.components);
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.listBoxAgentType = new System.Windows.Forms.ListBox();
            this.textBox_K01 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_V01 = new System.Windows.Forms.TextBox();
            this.textBox_V02 = new System.Windows.Forms.TextBox();
            this.textBox_K02 = new System.Windows.Forms.TextBox();
            this.textBox_V03 = new System.Windows.Forms.TextBox();
            this.textBox_K03 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_AgentLat = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_AgentLng = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.listBoxAgentList = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelAgentProperties = new System.Windows.Forms.Label();
            this.listBoxConsole = new System.Windows.Forms.ListBox();
            this.textBox_V04 = new System.Windows.Forms.TextBox();
            this.textBox_K04 = new System.Windows.Forms.TextBox();
            this.textBox_V05 = new System.Windows.Forms.TextBox();
            this.textBox_K05 = new System.Windows.Forms.TextBox();
            this.textBox_V06 = new System.Windows.Forms.TextBox();
            this.textBox_K06 = new System.Windows.Forms.TextBox();
            this.listBoxAgentControl = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.listBoxJoinedAgentList = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.gMapExplorer = new GMap.NET.WindowsForms.GMapControl();
            this.labelLatLng = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelMouseStatus = new System.Windows.Forms.Label();
            this.buttonCreateTP = new System.Windows.Forms.Button();
            this.textBox_TPThreads = new System.Windows.Forms.TextBox();
            this.label_ThreadNumber = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonCreate
            // 
            this.buttonCreate.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonCreate.Location = new System.Drawing.Point(222, 364);
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.Size = new System.Drawing.Size(134, 36);
            this.buttonCreate.TabIndex = 1;
            this.buttonCreate.Text = "Create New Agent";
            this.buttonCreate.UseVisualStyleBackColor = true;
            this.buttonCreate.Click += new System.EventHandler(this.buttonCreate_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Font = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonStart.Location = new System.Drawing.Point(362, 364);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(102, 36);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "Start Simulation";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonPause
            // 
            this.buttonPause.Font = new System.Drawing.Font("微軟正黑體", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonPause.Location = new System.Drawing.Point(470, 364);
            this.buttonPause.Name = "buttonPause";
            this.buttonPause.Size = new System.Drawing.Size(109, 36);
            this.buttonPause.TabIndex = 4;
            this.buttonPause.Text = "Pause Simulation";
            this.buttonPause.UseVisualStyleBackColor = true;
            this.buttonPause.Click += new System.EventHandler(this.buttonPause_Click);
            // 
            // SimulationTimer
            // 
            this.SimulationTimer.Interval = 200;
            this.SimulationTimer.Tick += new System.EventHandler(this.SimulationTimer_Tick);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.numericUpDown1.DecimalPlaces = 3;
            this.numericUpDown1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.numericUpDown1.Location = new System.Drawing.Point(585, 374);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(55, 22);
            this.numericUpDown1.TabIndex = 5;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown1.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // listBoxAgentType
            // 
            this.listBoxAgentType.FormattingEnabled = true;
            this.listBoxAgentType.ItemHeight = 12;
            this.listBoxAgentType.Location = new System.Drawing.Point(12, 60);
            this.listBoxAgentType.Name = "listBoxAgentType";
            this.listBoxAgentType.Size = new System.Drawing.Size(110, 100);
            this.listBoxAgentType.TabIndex = 6;
            this.listBoxAgentType.SelectedIndexChanged += new System.EventHandler(this.listBoxAgentType_SelectedIndexChanged);
            // 
            // textBox_K01
            // 
            this.textBox_K01.Location = new System.Drawing.Point(9, 187);
            this.textBox_K01.Name = "textBox_K01";
            this.textBox_K01.Size = new System.Drawing.Size(88, 22);
            this.textBox_K01.TabIndex = 7;
            this.textBox_K01.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(9, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 21);
            this.label1.TabIndex = 8;
            this.label1.Text = "Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(9, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 21);
            this.label2.TabIndex = 9;
            this.label2.Text = "New Agent Properties";
            // 
            // textBox_V01
            // 
            this.textBox_V01.Location = new System.Drawing.Point(103, 187);
            this.textBox_V01.Name = "textBox_V01";
            this.textBox_V01.Size = new System.Drawing.Size(113, 22);
            this.textBox_V01.TabIndex = 10;
            // 
            // textBox_V02
            // 
            this.textBox_V02.Location = new System.Drawing.Point(103, 215);
            this.textBox_V02.Name = "textBox_V02";
            this.textBox_V02.Size = new System.Drawing.Size(113, 22);
            this.textBox_V02.TabIndex = 12;
            // 
            // textBox_K02
            // 
            this.textBox_K02.Location = new System.Drawing.Point(9, 215);
            this.textBox_K02.Name = "textBox_K02";
            this.textBox_K02.Size = new System.Drawing.Size(88, 22);
            this.textBox_K02.TabIndex = 11;
            this.textBox_K02.Text = "Year";
            // 
            // textBox_V03
            // 
            this.textBox_V03.Location = new System.Drawing.Point(103, 243);
            this.textBox_V03.Name = "textBox_V03";
            this.textBox_V03.Size = new System.Drawing.Size(113, 22);
            this.textBox_V03.TabIndex = 14;
            // 
            // textBox_K03
            // 
            this.textBox_K03.Location = new System.Drawing.Point(9, 243);
            this.textBox_K03.Name = "textBox_K03";
            this.textBox_K03.Size = new System.Drawing.Size(88, 22);
            this.textBox_K03.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(9, 372);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 21);
            this.label3.TabIndex = 15;
            this.label3.Text = "Agent Coordinate";
            // 
            // textBox_AgentLat
            // 
            this.textBox_AgentLat.Location = new System.Drawing.Point(45, 408);
            this.textBox_AgentLat.Name = "textBox_AgentLat";
            this.textBox_AgentLat.Size = new System.Drawing.Size(160, 22);
            this.textBox_AgentLat.TabIndex = 16;
            this.textBox_AgentLat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_C0X_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(15, 408);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 17);
            this.label5.TabIndex = 19;
            this.label5.Text = "Lat";
            // 
            // textBox_AgentLng
            // 
            this.textBox_AgentLng.Location = new System.Drawing.Point(45, 443);
            this.textBox_AgentLng.Name = "textBox_AgentLng";
            this.textBox_AgentLng.Size = new System.Drawing.Size(160, 22);
            this.textBox_AgentLng.TabIndex = 20;
            this.textBox_AgentLng.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_C0X_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label9.Location = new System.Drawing.Point(646, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 21);
            this.label9.TabIndex = 30;
            this.label9.Text = "AgentList";
            // 
            // listBoxAgentList
            // 
            this.listBoxAgentList.FormattingEnabled = true;
            this.listBoxAgentList.ItemHeight = 12;
            this.listBoxAgentList.Location = new System.Drawing.Point(650, 33);
            this.listBoxAgentList.Name = "listBoxAgentList";
            this.listBoxAgentList.Size = new System.Drawing.Size(157, 124);
            this.listBoxAgentList.TabIndex = 31;
            this.listBoxAgentList.SelectedIndexChanged += new System.EventHandler(this.listBoxAgentList_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(646, 163);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(139, 21);
            this.label10.TabIndex = 32;
            this.label10.Text = "Agent Properties";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label11.Location = new System.Drawing.Point(11, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 21);
            this.label11.TabIndex = 33;
            this.label11.Text = "Create Agent";
            // 
            // labelAgentProperties
            // 
            this.labelAgentProperties.AutoSize = true;
            this.labelAgentProperties.Font = new System.Drawing.Font("細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labelAgentProperties.Location = new System.Drawing.Point(653, 190);
            this.labelAgentProperties.MaximumSize = new System.Drawing.Size(300, 0);
            this.labelAgentProperties.Name = "labelAgentProperties";
            this.labelAgentProperties.Size = new System.Drawing.Size(95, 12);
            this.labelAgentProperties.TabIndex = 34;
            this.labelAgentProperties.Text = "properties here";
            // 
            // listBoxConsole
            // 
            this.listBoxConsole.FormattingEnabled = true;
            this.listBoxConsole.ItemHeight = 12;
            this.listBoxConsole.Items.AddRange(new object[] {
            "This is my Console"});
            this.listBoxConsole.Location = new System.Drawing.Point(222, 401);
            this.listBoxConsole.Name = "listBoxConsole";
            this.listBoxConsole.Size = new System.Drawing.Size(418, 100);
            this.listBoxConsole.TabIndex = 35;
            // 
            // textBox_V04
            // 
            this.textBox_V04.Location = new System.Drawing.Point(103, 271);
            this.textBox_V04.Name = "textBox_V04";
            this.textBox_V04.Size = new System.Drawing.Size(113, 22);
            this.textBox_V04.TabIndex = 37;
            // 
            // textBox_K04
            // 
            this.textBox_K04.Location = new System.Drawing.Point(9, 271);
            this.textBox_K04.Name = "textBox_K04";
            this.textBox_K04.Size = new System.Drawing.Size(88, 22);
            this.textBox_K04.TabIndex = 36;
            // 
            // textBox_V05
            // 
            this.textBox_V05.Location = new System.Drawing.Point(103, 299);
            this.textBox_V05.Name = "textBox_V05";
            this.textBox_V05.Size = new System.Drawing.Size(113, 22);
            this.textBox_V05.TabIndex = 39;
            // 
            // textBox_K05
            // 
            this.textBox_K05.Location = new System.Drawing.Point(9, 299);
            this.textBox_K05.Name = "textBox_K05";
            this.textBox_K05.Size = new System.Drawing.Size(88, 22);
            this.textBox_K05.TabIndex = 38;
            // 
            // textBox_V06
            // 
            this.textBox_V06.Location = new System.Drawing.Point(103, 327);
            this.textBox_V06.Name = "textBox_V06";
            this.textBox_V06.Size = new System.Drawing.Size(113, 22);
            this.textBox_V06.TabIndex = 41;
            // 
            // textBox_K06
            // 
            this.textBox_K06.Location = new System.Drawing.Point(9, 327);
            this.textBox_K06.Name = "textBox_K06";
            this.textBox_K06.Size = new System.Drawing.Size(88, 22);
            this.textBox_K06.TabIndex = 40;
            // 
            // listBoxAgentControl
            // 
            this.listBoxAgentControl.FormattingEnabled = true;
            this.listBoxAgentControl.ItemHeight = 12;
            this.listBoxAgentControl.Location = new System.Drawing.Point(128, 60);
            this.listBoxAgentControl.Name = "listBoxAgentControl";
            this.listBoxAgentControl.Size = new System.Drawing.Size(88, 100);
            this.listBoxAgentControl.TabIndex = 42;
            this.listBoxAgentControl.SelectedIndexChanged += new System.EventHandler(this.listBoxAgentControl_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(124, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 21);
            this.label12.TabIndex = 43;
            this.label12.Text = "Ctrl";
            // 
            // listBoxJoinedAgentList
            // 
            this.listBoxJoinedAgentList.FormattingEnabled = true;
            this.listBoxJoinedAgentList.ItemHeight = 12;
            this.listBoxJoinedAgentList.Location = new System.Drawing.Point(825, 33);
            this.listBoxJoinedAgentList.Name = "listBoxJoinedAgentList";
            this.listBoxJoinedAgentList.Size = new System.Drawing.Size(151, 124);
            this.listBoxJoinedAgentList.TabIndex = 44;
            this.listBoxJoinedAgentList.SelectedIndexChanged += new System.EventHandler(this.listBoxJoinedAgentList_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label13.Location = new System.Drawing.Point(821, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 21);
            this.label13.TabIndex = 45;
            this.label13.Text = "JoinedAgentList";
            // 
            // gMapExplorer
            // 
            this.gMapExplorer.Bearing = 0F;
            this.gMapExplorer.CanDragMap = true;
            this.gMapExplorer.GrayScaleMode = false;
            this.gMapExplorer.LevelsKeepInMemmory = 5;
            this.gMapExplorer.Location = new System.Drawing.Point(222, 12);
            this.gMapExplorer.MarkersEnabled = true;
            this.gMapExplorer.MaxZoom = 2;
            this.gMapExplorer.MinZoom = 2;
            this.gMapExplorer.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gMapExplorer.Name = "gMapExplorer";
            this.gMapExplorer.NegativeMode = false;
            this.gMapExplorer.PolygonsEnabled = true;
            this.gMapExplorer.RetryLoadTile = 0;
            this.gMapExplorer.RoutesEnabled = true;
            this.gMapExplorer.ShowTileGridLines = false;
            this.gMapExplorer.Size = new System.Drawing.Size(418, 337);
            this.gMapExplorer.TabIndex = 46;
            this.gMapExplorer.Zoom = 0D;
            this.gMapExplorer.Load += new System.EventHandler(this.gMapExplorer_Load);
            // 
            // labelLatLng
            // 
            this.labelLatLng.AutoSize = true;
            this.labelLatLng.Location = new System.Drawing.Point(220, 349);
            this.labelLatLng.Name = "labelLatLng";
            this.labelLatLng.Size = new System.Drawing.Size(61, 12);
            this.labelLatLng.TabIndex = 47;
            this.labelLatLng.Text = "labelLatLng";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(15, 443);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 17);
            this.label6.TabIndex = 19;
            this.label6.Text = "Lng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(502, 349);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 12);
            this.label7.TabIndex = 48;
            this.label7.Text = "Mouse Status:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelMouseStatus
            // 
            this.labelMouseStatus.AutoSize = true;
            this.labelMouseStatus.Location = new System.Drawing.Point(577, 349);
            this.labelMouseStatus.Name = "labelMouseStatus";
            this.labelMouseStatus.Size = new System.Drawing.Size(63, 12);
            this.labelMouseStatus.TabIndex = 49;
            this.labelMouseStatus.Text = "mouse status";
            this.labelMouseStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // buttonCreateTP
            // 
            this.buttonCreateTP.Location = new System.Drawing.Point(908, 566);
            this.buttonCreateTP.Name = "buttonCreateTP";
            this.buttonCreateTP.Size = new System.Drawing.Size(68, 40);
            this.buttonCreateTP.TabIndex = 50;
            this.buttonCreateTP.Text = "Create ThreadPool";
            this.buttonCreateTP.UseVisualStyleBackColor = true;
            this.buttonCreateTP.Click += new System.EventHandler(this.buttonCreateTP_Click);
            // 
            // textBox_TPThreads
            // 
            this.textBox_TPThreads.Location = new System.Drawing.Point(802, 584);
            this.textBox_TPThreads.Name = "textBox_TPThreads";
            this.textBox_TPThreads.Size = new System.Drawing.Size(100, 22);
            this.textBox_TPThreads.TabIndex = 51;
            this.textBox_TPThreads.Text = "4";
            // 
            // label_ThreadNumber
            // 
            this.label_ThreadNumber.AutoSize = true;
            this.label_ThreadNumber.Location = new System.Drawing.Point(800, 566);
            this.label_ThreadNumber.Name = "label_ThreadNumber";
            this.label_ThreadNumber.Size = new System.Drawing.Size(48, 12);
            this.label_ThreadNumber.TabIndex = 52;
            this.label_ThreadNumber.Text = "#Threads";
            this.label_ThreadNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 618);
            this.Controls.Add(this.label_ThreadNumber);
            this.Controls.Add(this.textBox_TPThreads);
            this.Controls.Add(this.buttonCreateTP);
            this.Controls.Add(this.labelMouseStatus);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelLatLng);
            this.Controls.Add(this.gMapExplorer);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.listBoxJoinedAgentList);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.listBoxConsole);
            this.Controls.Add(this.listBoxAgentType);
            this.Controls.Add(this.listBoxAgentControl);
            this.Controls.Add(this.labelAgentProperties);
            this.Controls.Add(this.textBox_K01);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox_V06);
            this.Controls.Add(this.listBoxAgentList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_K06);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_V05);
            this.Controls.Add(this.textBox_V01);
            this.Controls.Add(this.textBox_K05);
            this.Controls.Add(this.textBox_K02);
            this.Controls.Add(this.textBox_V04);
            this.Controls.Add(this.textBox_V02);
            this.Controls.Add(this.textBox_K04);
            this.Controls.Add(this.textBox_K03);
            this.Controls.Add(this.textBox_AgentLng);
            this.Controls.Add(this.textBox_V03);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox_AgentLat);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.buttonPause);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.buttonCreate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainWindow";
            this.Text = "Agent-Based Model 2D";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCreate;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonPause;
        public System.Windows.Forms.Timer SimulationTimer;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ListBox listBoxAgentType;
        private System.Windows.Forms.TextBox textBox_K01;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_V01;
        private System.Windows.Forms.TextBox textBox_V02;
        private System.Windows.Forms.TextBox textBox_K02;
        private System.Windows.Forms.TextBox textBox_V03;
        private System.Windows.Forms.TextBox textBox_K03;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_AgentLat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_AgentLng;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox listBoxAgentList;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelAgentProperties;
        private System.Windows.Forms.ListBox listBoxConsole;
        private System.Windows.Forms.TextBox textBox_V04;
        private System.Windows.Forms.TextBox textBox_K04;
        private System.Windows.Forms.TextBox textBox_V05;
        private System.Windows.Forms.TextBox textBox_K05;
        private System.Windows.Forms.TextBox textBox_V06;
        private System.Windows.Forms.TextBox textBox_K06;
        private System.Windows.Forms.ListBox listBoxAgentControl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox listBoxJoinedAgentList;
        private System.Windows.Forms.Label label13;
        private GMap.NET.WindowsForms.GMapControl gMapExplorer;
        private System.Windows.Forms.Label labelLatLng;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelMouseStatus;
        private System.Windows.Forms.Button buttonCreateTP;
        private System.Windows.Forms.TextBox textBox_TPThreads;
        private System.Windows.Forms.Label label_ThreadNumber;
    }
}

